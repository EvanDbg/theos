#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>
#import "SPSettingsController.h"
#import "UIColor+Hex.h"

@interface SPButtonCell : PSTableCell

@end
