// UIColor

@interface UIColor (Hex)
+ (id)colorFromHex:(NSString *)hexString;
@end
