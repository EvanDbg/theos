#include "@@CLASSPREFIX@@RootListController.h"

@implementation @@CLASSPREFIX@@RootListController
- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];

	UIBarButtonItem *applyButton = [[UIBarButtonItem alloc] initWithTitle: @"注销" 
																	style: UIBarButtonItemStylePlain 
																   target: self 
																   action: @selector(respring)];
	self.navigationItem.rightBarButtonItem = applyButton;
}

-(void)showHelp {
	[[Welcome@@CLASSPREFIX@@ shareInstance] showWelcome];
}

-(void)joinQQ {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString: @"https://jq.qq.com/?_wv=1027&k=IOnHbk10"] options:@{} completionHandler:nil];
}
@end
