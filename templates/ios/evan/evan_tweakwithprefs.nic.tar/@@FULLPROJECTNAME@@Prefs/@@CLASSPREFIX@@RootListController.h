#import "SkittyPrefs/SPSettingsController.h"
#import <Preferences/PSSpecifier.h>
#import <objc/runtime.h>
#import "../Welcome.h"

@interface @@CLASSPREFIX@@RootListController : SPSettingsController

@end
